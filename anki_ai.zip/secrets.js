// API Keys and Configuration
// Replace the values below with your actual API keys

export const NOTION_API_KEY = "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";
export const NOTION_PAGE_ID = "267ad5f651558081a9fdfa77fd4da2c5";
export const OPENAI_API_KEY = "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";
